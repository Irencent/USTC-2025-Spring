数据描述

all_hero_init_attr.csv是王者荣耀英雄初始属性值数据

全部英雄赛事数据20200801-20210801.xlsx是王者荣耀2021年8月近一年的全部赛事数据

hero_skins.csv是英雄皮肤数据

hero_job.xlsx是涉及英雄以及对应的职业数据

数据来源

all_hero_init_attr.csv来源于和鲸社区，作者灰海豚fnpk

```
@misc{1233zxc5577,
    title = { 王者荣耀英雄分析 },
    author = { 灰海豚fnpk },
    howpublished = { \url{https://www.heywhale.com/mw/dataset/64131bea3621814014939877} },
    year = { 2023 },
}
```

全部英雄赛事数据20200801-20210801.xlsx来源于王者荣耀官网

hero_skins.csv来源于和鲸社区，作者Python研究者

```
@misc{08176706,
    title = { 王者荣耀英雄皮肤数据 },
    author = { Python研究者 },
    howpublished = { \url{https://www.heywhale.com/mw/dataset/611bb335fe727700176eefdf} },
    year = { 2021 },
}
```

hero_job.xlsx结合官网资料自行统计

