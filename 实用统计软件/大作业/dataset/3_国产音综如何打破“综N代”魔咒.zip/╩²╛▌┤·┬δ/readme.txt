第一部分
文件名：
db1.xlsx：《我们的歌》第一季在豆瓣平台的短评。（案例.html使用数据）
db2.xlsx：《我们的歌》第二季在豆瓣平台的短评。
db3.xlsx：《我们的歌》第三季在豆瓣平台的短评。
变量名：
Name：豆瓣用户名；content：短评内容；like：有用数；
postdate：评论时间；star：短评星级；
follower：用户关注数；fan：用户粉丝数。


第二部分
文件名：
wb1.xlsx：第一季播出周期，微博词条“我们的歌”的热门博文。
wb2.xlsx：第二季播出周期，微博词条“我们的歌”的热门博文。
wb3.xlsx：第二季播出周期，微博词条“我们的歌”的热门博文。（案例使用数据）
变量名：
Name：微博用户名；postdate：发博日期；posttime：发博时间；
content：博文内容；zf：博文转发量；pl：博文评论量；dz：博文点赞量；
follower：用户关注数；fan：用户粉丝数；num：用户博文总数；
if_vedio：博文有无视频；if_tag：博文有无话题TAG。


第三部分
文件名：
userwords.txt：自定义词典（包含《我们的歌》各季的嘉宾名、演出曲目等常用词）。
stopwords.txt：常用的停用词汇。
