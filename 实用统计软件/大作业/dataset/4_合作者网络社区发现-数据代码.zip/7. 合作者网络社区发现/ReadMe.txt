edge_largest.csv是网络边数据，一条观测由两个节点构成，代表着两个节点构成的一条边。
author.csv是部分作者信息，包括作者的唯一标识（name）、作者姓名（author）、作者单位（university）