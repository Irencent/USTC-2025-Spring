案例数据"paper_cleaning.csv"和"paper_edge_citation_clean.csv"提供了已经经过预处理的四大文章及引用信息。

"paper_cleaning.csv"包含了5746篇四大文章的信息，每条数据包含2个变量：文章标题，文章编号。

"paper_edge_citation.csv"是按边（edge）储存的四大文章引用信息，共计23737条引用，每条数据代表一条边，包含一条边的两个节点：文章编号（source），被引文章编号（target）。该网络的边从每篇文章节点出发指向其引用的文章节点，是一个有向无权的网络。